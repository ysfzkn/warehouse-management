# Warehouse Management System

A modern, mobile-friendly warehouse management system designed for white goods companies. This system allows you to manage your warehouse products categorically and numerically, view and update stock status.

![Java](https://img.shields.io/badge/Java-17-orange)
![Spring Boot](https://img.shields.io/badge/Spring%20Boot-3.1.5-brightgreen)
![React](https://img.shields.io/badge/React-18.2.0-blue)
![License](https://img.shields.io/badge/License-MIT-yellow)

## 🌟 Features

- **Multi-Warehouse Support**: Manage multiple warehouses
- **Product Management**: Product categorization and detailed product information
- **Stock Tracking**: Real-time stock tracking and alerts
- **Category Management**: Flexible category system
- **Mobile Responsive**: Perfect experience on mobile devices
- **Modern UI**: Stylish and user-friendly interface with Bootstrap
- **RESTful API**: Standard API endpoints
- **Docker Ready**: Containerized deployment
- **Real-time Dashboard**: Comprehensive statistics and reports

## 📋 Requirements

- **Docker & Docker Compose** (Recommended)
- **Java 17+** (If not using Docker)
- **Node.js 18+** (If not using Docker)
- **Git**

## 🚀 Quick Start

### With Docker (Recommended)

1. **Clone the repository:**
   ```bash
   git clone <repository-url>
   cd warehouse-management
   ```

2. **Run the deploy script:**
   ```bash
   ./deploy.sh
   ```

3. **Use the system:**
   - **Frontend**: http://localhost
   - **Backend API**: http://localhost/api
   - **H2 Console**: http://localhost:8080/h2-console

### Manual Installation

1. **Start the backend:**
   ```bash
   # Download Maven dependencies
   mvn clean install

   # Run the application
   mvn spring-boot:run
   ```

2. **Start the frontend:**
   ```bash
   cd frontend
   npm install
   npm start
   ```

## 📊 System Architecture

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   React Frontend │◄──►│  Spring Boot    │◄──►│   H2 Database   │
│                 │    │   Backend API   │    │  (In-Memory)    │
│ - Responsive UI │    │                 │    │                 │
│ - Modern Design │    │ - REST API      │    │ - JPA Entities  │
│ - Real-time     │    │ - Business      │    │ - Relationships │
│   Updates       │    │   Logic         │    │                 │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

## 🏗️ Database Schema

### Categories
- `id`: Primary Key
- `name`: Category name
- `description`: Description
- `created_at`: Creation date
- `updated_at`: Update date

### Warehouses
- `id`: Primary Key
- `name`: Warehouse name
- `location`: Location
- `phone`: Phone
- `manager`: Manager
- `capacity_sqm`: Capacity (m²)
- `is_active`: Active status

### Products
- `id`: Primary Key
- `name`: Product name
- `description`: Description
- `sku`: Stock code
- `price`: Price
- `weight`: Weight
- `dimensions`: Dimensions
- `category_id`: Category reference
- `is_active`: Active status

### Stocks
- `id`: Primary Key
- `product_id`: Product reference
- `warehouse_id`: Warehouse reference
- `quantity`: Quantity
- `min_stock_level`: Minimum stock level
- `reserved_quantity`: Reserved quantity
- `last_updated`: Last update

## 🔌 API Endpoints

### Categories
- `GET /api/categories` - List all categories
- `GET /api/categories/{id}` - Get category details
- `POST /api/categories` - Create new category
- `PUT /api/categories/{id}` - Update category
- `DELETE /api/categories/{id}` - Delete category

### Warehouses
- `GET /api/warehouses` - List all warehouses
- `GET /api/warehouses/{id}` - Get warehouse details
- `POST /api/warehouses` - Create new warehouse
- `PUT /api/warehouses/{id}` - Update warehouse
- `DELETE /api/warehouses/{id}` - Delete warehouse
- `PUT /api/warehouses/{id}/activate` - Activate warehouse
- `PUT /api/warehouses/{id}/deactivate` - Deactivate warehouse

### Products
- `GET /api/products` - List all products
- `GET /api/products/{id}` - Get product details
- `GET /api/products/sku/{sku}` - Find product by SKU
- `POST /api/products` - Create new product
- `PUT /api/products/{id}` - Update product
- `DELETE /api/products/{id}` - Delete product

### Stocks
- `GET /api/stocks` - List all stocks
- `GET /api/stocks/{id}` - Get stock details
- `GET /api/stocks/product/{productId}` - Get stocks by product
- `GET /api/stocks/warehouse/{warehouseId}` - Get stocks by warehouse
- `POST /api/stocks` - Create new stock record
- `PUT /api/stocks/{id}` - Update stock
- `PUT /api/stocks/{id}/add` - Add to stock
- `PUT /api/stocks/{id}/remove` - Remove from stock

## 🎨 User Interface

### Dashboard
- General statistics
- Low stock alerts
- Charts and graphs
- Quick access buttons

### Warehouse Management
- Warehouse list and details
- Stock viewing by warehouse
- Warehouse activation/deactivation

### Product Management
- Product list and search
- Category-based filtering
- Add/edit products

### Category Management
- Category hierarchy
- Product counts
- Category-based reports

### Stock Management
- Real-time stock tracking
- Low stock alerts
- Stock movements

## 🔧 Configuration

### Environment Variables (Backend)
```properties
# Server Configuration
server.port=8080

# Database Configuration
spring.datasource.url=jdbc:h2:mem:warehouse_db
spring.datasource.username=sa
spring.datasource.password=password

# H2 Console (Development)
spring.h2.console.enabled=true
```

### Docker Environment
```yaml
# docker-compose.yml
backend:
  environment:
    - SPRING_PROFILES_ACTIVE=docker
```

## 🐳 Docker Usage

### Development Environment
```bash
# Start all services
docker-compose up -d

# View logs
docker-compose logs -f backend
docker-compose logs -f frontend

# Stop services
docker-compose down
```

### Production Deployment
```bash
# Production build
docker-compose -f docker-compose.prod.yml up -d

# With SSL certificate
# Edit nginx/prod.conf file
```

## 🚀 Production Deployment

### VPS/Dedicated Server
1. Clone repository to server
2. Get SSL certificate (Let's Encrypt recommended)
3. Update `nginx/prod.conf` file
4. Run `./deploy.sh production` command

### Cloud Platforms
- **AWS**: ECS Fargate + RDS
- **Google Cloud**: Cloud Run + Cloud SQL
- **Azure**: Container Instances + Database
- **DigitalOcean**: App Platform

## 📱 Mobile Compatibility

- Responsive Bootstrap design
- Touch-friendly interface
- Progressive Web App (PWA) support
- Mobile-first approach

## 🔒 Security

- CORS configuration
- Input validation
- SQL injection protection (JPA)
- XSS protection
- Security headers

## 📊 Performance

- Lazy loading
- Caching strategies
- Database indexing
- Optimized queries
- CDN support

## 🧪 Testing

### Backend Tests
```bash
mvn test
```

### Frontend Tests
```bash
cd frontend
npm test
```

## 📝 Logging

- Structured logging (Spring Boot)
- Request/Response logging
- Error tracking
- Performance monitoring

## 🔄 Backup & Recovery

### Database Backup (H2)
```bash
# CSV export via H2 console
http://localhost:8080/h2-console
```

### Docker Volumes
```bash
# Volume backup
docker run --rm -v warehouse_postgres_data:/data -v $(pwd):/backup alpine tar czf /backup/postgres_backup.tar.gz -C /data .
```

## 🤝 Contributing

1. Fork the project
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.

## 🆘 Support

If you encounter any issues:

1. Check the [Issues](https://github.com/your-repo/issues) page
2. Open a new issue
3. Contact via email

## 👥 Developers

- **Backend**: Spring Boot, Java 17, REST API
- **Frontend**: React 18, Bootstrap 5, Chart.js
- **Database**: H2 (Development), PostgreSQL (Production)
- **DevOps**: Docker, Docker Compose, Nginx

## 🗺️ Roadmap

- [ ] Multi-language support (TR/EN)
- [ ] Advanced reporting
- [ ] Barcode/QR code integration
- [ ] Mobile app (React Native)
- [ ] Real-time notifications
- [ ] Advanced analytics
- [ ] Multi-tenant support
- [ ] API rate limiting

---

⭐ If you like this project, don't forget to give it a star!
