# Warehouse Management System - Frontend

React tabanlı, mobil uyumlu depo yönetim sistemi arayüzü.

## 🚀 Özellikler

- **Modern React 18** - En son React özelliklerini kullanır
- **Responsive Design** - Mobil, tablet ve desktop uyumlu
- **Bootstrap 5** - Modern ve şık UI bileşenleri
- **Chart.js Integration** - Dashboard için grafikler
- **Real-time Updates** - Anlık veri güncellemeleri
- **Form Validation** - Client-side validasyon
- **Error Handling** - Kapsamlı hata yönetimi

## 📋 Gereksinimler

- **Node.js 18+**
- **npm** veya **yarn**
- **Modern web tarayıcı**

## 🛠️ Kurulum

### 1. Dependencies'leri yükleyin

```bash
npm install
```

### 2. Development server'ı başlatın

```bash
npm start
```

Uygulama http://localhost:3000 adresinde açılacaktır.

### 3. Production build

```bash
npm run build
```

Build dosyaları `build/` klasöründe oluşturulacaktır.

## 📁 Proje Yapısı

```
frontend/
├── public/
│   └── index.html          # Ana HTML dosyası
├── src/
│   ├── components/         # Yeniden kullanılabilir bileşenler
│   │   ├── Navbar.js       # Navigasyon çubuğu
│   │   ├── WarehouseForm.js # Depo formu
│   │   ├── ProductForm.js   # Ürün formu
│   │   ├── CategoryForm.js  # Kategori formu
│   │   ├── StockForm.js     # Stok formu
│   │   ├── StockModal.js    # Stok görüntüleme modalı
│   │   └── StockAdjustmentModal.js # Stok ayarlama modalı
│   ├── pages/              # Sayfa bileşenleri
│   │   ├── Dashboard.js     # Ana dashboard
│   │   ├── Warehouses.js    # Depo yönetimi
│   │   ├── Products.js      # Ürün yönetimi
│   │   ├── Categories.js    # Kategori yönetimi
│   │   └── Stock.js         # Stok yönetimi
│   ├── App.js              # Ana uygulama bileşeni
│   ├── index.js            # React DOM giriş noktası
│   ├── App.css             # Ana stil dosyası
│   └── index.css           # Global stiller
├── package.json            # Proje dependencies ve scripts
├── Dockerfile              # Docker konfigürasyonu
└── nginx.conf              # Nginx proxy konfigürasyonu
```

## 🎨 Kullanılan Teknolojiler

### Core Technologies
- **React 18.2.0** - UI framework
- **React Router DOM 6.11.0** - Sayfa yönlendirme
- **Axios 1.4.0** - HTTP client
- **Bootstrap 5.2.3** - CSS framework
- **React Bootstrap 2.7.4** - Bootstrap React bileşenleri

### Additional Libraries
- **Chart.js 4.3.0** - Grafik ve chart'lar
- **React Chart.js 2 5.2.0** - Chart.js React wrapper
- **React Icons 4.10.1** - Icon kütüphanesi
- **React Scripts 5.0.1** - Build tools

## 🔧 Konfigürasyon

### Environment Variables

`.env` dosyası oluşturarak API URL'ini yapılandırabilirsiniz:

```env
REACT_APP_API_URL=http://localhost:8080/api
```

### Proxy Configuration

`package.json` içinde proxy yapılandırması:

```json
{
  "proxy": "http://localhost:8080"
}
```

Bu sayede `/api` endpoint'leri otomatik olarak backend'e yönlendirilir.

## 🚀 Development

### Development Server

```bash
npm start
```

- Hot reload enabled
- Error overlay
- http://localhost:3000

### Code Quality

```bash
# Lint kodu
npm run lint

# Test çalıştırma
npm test

# Build production
npm run build
```

## 📱 Responsive Design

### Breakpoints

- **Mobile**: < 576px
- **Tablet**: 576px - 768px
- **Desktop**: > 768px

### Mobile Optimizations

- Touch-friendly butonlar
- Responsive tablolar
- Collapsible navigation
- Optimized form layouts

## 🎯 Component Usage

### Navbar

Ana navigasyon bileşeni:

```jsx
import Navbar from './components/Navbar';

function App() {
  return (
    <div>
      <Navbar />
      {/* Sayfa içeriği */}
    </div>
  );
}
```

### Form Components

Form bileşenleri validasyon ve error handling ile birlikte gelir:

```jsx
import ProductForm from './components/ProductForm';

function ProductsPage() {
  const handleSuccess = () => {
    // Form başarıyla gönderildiğinde
    console.log('Ürün kaydedildi');
  };

  return (
    <ProductForm
      product={editingProduct}
      categories={categories}
      onSuccess={handleSuccess}
      onCancel={() => setShowForm(false)}
    />
  );
}
```

### API Integration

Axios ile API çağrıları:

```jsx
import axios from 'axios';

const fetchProducts = async () => {
  try {
    const response = await axios.get('/api/products');
    setProducts(response.data);
  } catch (error) {
    console.error('Ürünler yüklenirken hata:', error);
    setError('Ürünler yüklenemedi');
  }
};
```

## 🔍 State Management

React useState ve useEffect hook'ları kullanılmaktadır:

```jsx
const [products, setProducts] = useState([]);
const [loading, setLoading] = useState(true);
const [error, setError] = useState(null);

useEffect(() => {
  fetchProducts();
}, []);
```

## 🎨 Styling

### CSS Modules

Bileşen bazlı stil dosyaları:

```css
/* ProductForm.module.css */
.formContainer {
  max-width: 600px;
  margin: 0 auto;
}

.error {
  color: #dc3545;
  font-size: 0.875rem;
}
```

### Bootstrap Utilities

Responsive grid sistemi:

```jsx
<div className="row">
  <div className="col-md-6 col-lg-4">
    {/* İçerik */}
  </div>
</div>
```

## 📊 Dashboard Components

### Charts

Chart.js entegrasyonu:

```jsx
import { Bar, Pie } from 'react-chartjs-2';

const chartData = {
  labels: ['Depolar', 'Ürünler', 'Kategoriler'],
  datasets: [{
    data: [5, 150, 10],
    backgroundColor: ['#007bff', '#28a745', '#ffc107']
  }]
};

<Pie data={chartData} />
```

## 🔒 Error Handling

Global error handling:

```jsx
const handleApiError = (error) => {
  if (error.response) {
    // Server response error
    setError(error.response.data.message);
  } else if (error.request) {
    // Network error
    setError('Ağ bağlantısı hatası');
  } else {
    // Other error
    setError('Bilinmeyen hata');
  }
};
```

## 🚀 Deployment

### Docker ile

```bash
# Build ve çalıştır
docker build -t warehouse-frontend .
docker run -p 80:80 warehouse-frontend
```

### Static Hosting

Build dosyalarını herhangi bir static hosting'e yükleyebilirsiniz:

```bash
npm run build
# build/ klasörünü hosting'e yükleyin
```

### Nginx Configuration

```nginx
server {
    listen 80;
    root /usr/share/nginx/html;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    location /api/ {
        proxy_pass http://backend:8080;
    }
}
```

## 🧪 Testing

### Unit Tests

```bash
npm test
```

### Test Coverage

```bash
npm test -- --coverage
```

### E2E Tests

Cypress veya Playwright eklenebilir.

## 📝 Code Style

### ESLint

```bash
npm run lint
```

### Prettier

Kod formatlaması için Prettier kullanılmaktadır.

## 🤝 Contributing

1. Feature branch oluşturun
2. Değişiklikleri yapın
3. Test edin
4. Pull request açın

## 📄 License

MIT License - detaylar için [LICENSE](../LICENSE) dosyasına bakın.

## 🆘 Troubleshooting

### Common Issues

**Build Error:**
```bash
rm -rf node_modules package-lock.json
npm install
```

**Port Already in Use:**
```bash
npx kill-port 3000
```

**API Connection Error:**
- Backend'in çalıştığından emin olun
- CORS ayarlarını kontrol edin
- Network tab'ında API çağrılarını inceleyin

### Debug Mode

```jsx
// Console logging ekleyin
console.log('API Response:', response.data);

// React DevTools kullanın
// Network tab'ını inceleyin
```

## 📞 Support

Herhangi bir sorun yaşarsanız:

1. Console error'larını kontrol edin
2. Network tab'ında API çağrılarını inceleyin
3. Browser DevTools kullanın
4. Issue açın

## 🗺️ Roadmap

- [ ] Dark mode desteği
- [ ] Offline PWA desteği
- [ ] Advanced filtering
- [ ] Drag & drop upload
- [ ] Real-time notifications
- [ ] Mobile app (React Native)
- [ ] Advanced charts
- [ ] Export functionality
