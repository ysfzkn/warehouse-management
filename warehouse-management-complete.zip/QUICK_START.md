# 🚀 Hızlı Başlangıç Rehberi

Bu rehber, Warehouse Management System'i hızlıca çalıştırmanız için adım adım talimatlar içerir.

## 📋 Ön Gereksinimler

- **Docker & Docker Compose** (Önerilen)
- **Git** (Repository'yi klonlamak için)

## 🛠️ 1. Adım: Repository'yi Hazırlayın

```bash
# Repository'yi klonlayın
git clone <repository-url>
cd warehouse-management

# Dosya izinlerini kontrol edin
chmod +x deploy.sh
```

## 🚀 2. Adım: Sistemi Başlatın

### Otomatik Deployment (Önerilen)

```bash
# Tüm sistemi tek komutla başlatın
./deploy.sh
```

Bu komut:
- ✅ Docker imajlarını oluşturur
- ✅ Backend ve frontend servislerini başlatır
- ✅ Veritabanını hazırlar
- ✅ Health check yapar
- ✅ Size erişim bilgilerini gösterir

### Manuel Kurulum (Alternatif)

Eğer Docker kullanmak istemiyorsanız:

**Backend:**
```bash
# Gerekli dependencies'leri yükleyin
mvn clean install

# Uygulamayı başlatın
mvn spring-boot:run
```

**Frontend:**
```bash
cd frontend
npm install
npm start
```

## 🌐 3. Adım: Sisteme Erişin

Deployment başarılı olursa şu adreslere erişebilirsiniz:

| Servis | URL | Açıklama |
|--------|-----|----------|
| **Frontend** | http://localhost | Ana uygulama arayüzü |
| **Backend API** | http://localhost/api | REST API endpoints |
| **H2 Console** | http://localhost:8080/h2-console | Veritabanı konsolu |

## 🔑 4. Adım: İlk Giriş

### Varsayılan Veritabanı Bilgileri

**H2 Console Girişi:**
- **JDBC URL**: `jdbc:h2:mem:warehouse_db`
- **Username**: `sa`
- **Password**: `password`

### İlk Kullanım

1. **Tarayıcıda** http://localhost adresini açın
2. **Dashboard** sayfasında genel istatistikleri görün
3. **Kategoriler** bölümünden ilk kategoriyi oluşturun
4. **Ürünler** bölümünden ürünleri ekleyin
5. **Depolar** bölümünden depoları tanımlayın
6. **Stok** bölümünden stok kayıtları oluşturun

## 📱 Mobil Kullanım

Sistem mobil uyumludur:
- 📱 Telefonunuzda tarayıcı açın
- 🌐 http://localhost adresine gidin
- 📱 Responsive tasarım sayesinde mobil deneyimi yaşayın

## 🛑 Sistemi Durdurma

```bash
# Tüm servisleri durdurun
docker-compose down

# Veya sadece deployment script'i ile
./deploy.sh # (mevcut containerları durdurur)
```

## 🔍 Sorun Giderme

### Yaygın Sorunlar

**Port Çakışması:**
```bash
# 8080 portu kullanılıyorsa
docker-compose down
# portu değiştirin veya başka uygulamayı kapatın
```

**Build Hatası:**
```bash
# Cache'i temizleyip yeniden build edin
docker-compose build --no-cache
```

**API Bağlantı Hatası:**
- Backend servisinin çalıştığından emin olun
- `docker-compose logs backend` ile logları kontrol edin

### Logları İnceleme

```bash
# Tüm servislerin loglarını görün
docker-compose logs

# Sadece backend logları
docker-compose logs backend

# Sadece frontend logları
docker-compose logs frontend

# Real-time log takip
docker-compose logs -f
```

## 🎯 Örnek Kullanım Senaryoları

### Senaryo 1: Yeni Ürün Ekleme

1. **Kategoriler** → **Yeni Kategori** → "Beyaz Eşya" oluşturun
2. **Ürünler** → **Yeni Ürün** → Samsung Buzdolabı ekleyin
3. **Depolar** → **Yeni Depo** → Ana Depo oluşturun
4. **Stok** → **Yeni Stok Kaydı** → Ürün-depo-stok ilişkisi kurun

### Senaryo 2: Stok Takibi

1. **Dashboard** → Genel istatistikleri görün
2. **Stok** → Düşük stok uyarılarını kontrol edin
3. **Stok Ayarlama** ile miktarları güncelleyin

### Senaryo 3: Raporlama

1. **Dashboard** → Grafiklerden genel durumu analiz edin
2. **Depolar** → Depo bazında stokları görüntüleyin
3. **Ürünler** → Kategori bazında ürünleri filtreleyin

## 📊 Örnek Veri

Sistem H2 in-memory veritabanı kullandığı için her başlangıçta temizlenir. Test için örnek veriler:

```sql
-- Örnek kategori
INSERT INTO categories (name, description) VALUES ('Beyaz Eşya', 'Buzdolabı, çamaşır makinesi vb.');

-- Örnek depo
INSERT INTO warehouses (name, location, manager) VALUES ('Ana Depo', 'İstanbul', 'Ahmet Yılmaz');

-- Örnek ürün
INSERT INTO products (name, sku, price, category_id) VALUES ('Samsung Buzdolabı', 'BD-001', 15000.00, 1);
```

## 🔧 Gelişmiş Konfigürasyon

### Environment Variables

`docker-compose.yml` dosyasında ortam değişkenlerini düzenleyin:

```yaml
environment:
  - SPRING_PROFILES_ACTIVE=production
  - LOG_LEVEL=DEBUG
```

### Custom Port

```bash
# Farklı port kullanın
FRONTEND_PORT=3000 BACKEND_PORT=8081 docker-compose up
```

## 🚀 Production Deployment

### VPS/Dedicated Server

1. **SSL Sertifikası alın** (Let's Encrypt önerilir)
2. **Domain adınızı ayarlayın**
3. **nginx/prod.conf** dosyasını düzenleyin
4. **Deploy script'ini çalıştırın:**

```bash
# Production ortamında
ENV=production ./deploy.sh
```

### Cloud Deployment

**AWS:**
- ECS Fargate + RDS
- Load Balancer yapılandırın

**Google Cloud:**
- Cloud Run + Cloud SQL
- Load Balancer ekleyin

**Azure:**
- Container Instances + Database
- Traffic Manager yapılandırın

## 📞 Destek

Herhangi bir sorun yaşarsanız:

1. **Logları kontrol edin**: `docker-compose logs`
2. **Container durumunu görün**: `docker-compose ps`
3. **Health check yapın**: `curl http://localhost/health`
4. **Dokümantasyonu okuyun**: [README.md](README.md)
5. **Issue açın** veya email atın

## 🎉 Başarı!

Sistemi başarıyla çalıştırdınız! Artık depo yönetimi operasyonlarınızı dijital ortamda gerçekleştirebilirsiniz.

**İlk Adımlar:**
- 🔍 Dashboard'ı keşfedin
- 📦 İlk ürününüzü ekleyin
- 🏪 Depolarınızı tanımlayın
- 📊 Raporları inceleyin

Mutlu kullanımlar! 🚀
