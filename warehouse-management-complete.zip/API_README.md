# Warehouse Management System API Documentation

Bu dokümantasyon, Warehouse Management System'in RESTful API endpoints'lerini detaylı olarak açıklamaktadır.

Base URL: `http://localhost:8080/api`

## Authentication

Şu anda authentication sistemi implementasyonu yoktur. Tüm endpointler public'tir.

## Response Format

Tüm API yanıtları JSON formatında döner:

```json
{
  "success": true,
  "data": { ... },
  "message": "Operation completed successfully"
}
```

Hata durumlarında:

```json
{
  "success": false,
  "error": "Error message",
  "details": "Detailed error information"
}
```

## Categories API

Kategori yönetimi için endpointler.

### Tüm Kategorileri Listele

```http
GET /api/categories
```

**Response:**
```json
[
  {
    "id": 1,
    "name": "Beyaz Eşya",
    "description": "Buzdolabı, çamaşır makinesi vb.",
    "createdAt": "2024-01-01T10:00:00",
    "updatedAt": "2024-01-01T10:00:00",
    "products": []
  }
]
```

### Aktif Kategorileri Listele

```http
GET /api/categories/active
```

### Kategori Detayları

```http
GET /api/categories/{id}
```

### Kategori ile Ürünleri Listele

```http
GET /api/categories/{id}/with-products
```

### Yeni Kategori Oluştur

```http
POST /api/categories
Content-Type: application/json

{
  "name": "Elektronik",
  "description": "TV, bilgisayar, telefon vb."
}
```

**Validation:**
- `name`: Required, 2-50 characters, unique

### Kategori Güncelle

```http
PUT /api/categories/{id}
Content-Type: application/json

{
  "name": "Yeni Kategori Adı",
  "description": "Güncellenmiş açıklama"
}
```

### Kategori Sil

```http
DELETE /api/categories/{id}
```

**Note:** Ürün içeren kategoriler silinemez.

---

## Warehouses API

Depo yönetimi için endpointler.

### Tüm Depoları Listele

```http
GET /api/warehouses
```

### Aktif Depoları Listele

```http
GET /api/warehouses/active
```

### Depo Detayları

```http
GET /api/warehouses/{id}
```

### Depo ile Stokları Listele

```http
GET /api/warehouses/{id}/with-stocks
```

### Yeni Depo Oluştur

```http
POST /api/warehouses
Content-Type: application/json

{
  "name": "Ana Depo",
  "location": "İstanbul, Türkiye",
  "phone": "0212 555 0000",
  "manager": "Ahmet Yılmaz",
  "capacitySqm": 1000.5,
  "isActive": true
}
```

**Validation:**
- `name`: Required, 2-100 characters, unique
- `location`: Required, 5-255 characters

### Depo Güncelle

```http
PUT /api/warehouses/{id}
Content-Type: application/json

{
  "name": "Güncellenmiş Depo Adı",
  "location": "Ankara, Türkiye"
}
```

### Depo Sil

```http
DELETE /api/warehouses/{id}
```

### Depo Aktifleştir

```http
PUT /api/warehouses/{id}/activate
```

### Depo Pasifleştir

```http
PUT /api/warehouses/{id}/deactivate
```

---

## Products API

Ürün yönetimi için endpointler.

### Tüm Ürünleri Listele

```http
GET /api/products
```

### Aktif Ürünleri Listele

```http
GET /api/products/active
```

### Ürün Detayları

```http
GET /api/products/{id}
```

### Ürün ile Stokları Listele

```http
GET /api/products/{id}/with-stocks
```

### SKU ile Ürün Ara

```http
GET /api/products/sku/{sku}
```

### Kategoriye Göre Ürünler

```http
GET /api/products/category/{categoryId}
```

### Ürün Arama

```http
GET /api/products/search?name=buzdolabı
```

### Yeni Ürün Oluştur

```http
POST /api/products
Content-Type: application/json

{
  "name": "Samsung Buzdolabı",
  "description": "A++ enerji sınıfı",
  "sku": "BD-001",
  "price": 15000.00,
  "weight": 80.5,
  "dimensions": "60x60x180 cm",
  "category": {
    "id": 1
  },
  "isActive": true
}
```

**Validation:**
- `name`: Required, 2-100 characters
- `sku`: Required, 3-50 characters, unique
- `price`: Required, must be positive
- `category`: Required, must exist

### Ürün Güncelle

```http
PUT /api/products/{id}
Content-Type: application/json

{
  "name": "Güncellenmiş Ürün Adı",
  "price": 17500.00
}
```

### Ürün Sil

```http
DELETE /api/products/{id}
```

### Ürün Aktifleştir

```http
PUT /api/products/{id}/activate
```

### Ürün Pasifleştir

```http
PUT /api/products/{id}/deactivate
```

---

## Stocks API

Stok yönetimi için endpointler.

### Tüm Stokları Listele

```http
GET /api/stocks
```

### Stok Detayları

```http
GET /api/stocks/{id}
```

### Ürüne Göre Stoklar

```http
GET /api/stocks/product/{productId}
```

### Depoya Göre Stoklar

```http
GET /api/stocks/warehouse/{warehouseId}
```

### Ürün-Depo Kombinasyonuna Göre Stok

```http
GET /api/stocks/product/{productId}/warehouse/{warehouseId}
```

### Düşük Stok Ürünleri

```http
GET /api/stocks/low-stock
```

### Stok Dışı Ürünler

```http
GET /api/stocks/out-of-stock
```

### Depoya Göre Düşük Stok

```http
GET /api/stocks/warehouse/{warehouseId}/low-stock
```

### Ürüne Göre Toplam Miktar

```http
GET /api/stocks/product/{productId}/total-quantity
```

### Depoya Göre Toplam Miktar

```http
GET /api/stocks/warehouse/{warehouseId}/total-quantity
```

### Yeni Stok Kaydı Oluştur

```http
POST /api/stocks
Content-Type: application/json

{
  "product": {
    "id": 1
  },
  "warehouse": {
    "id": 1
  },
  "quantity": 100,
  "minStockLevel": 10,
  "reservedQuantity": 0
}
```

**Validation:**
- `product`: Required, must exist
- `warehouse`: Required, must exist
- `quantity`: Required, must be >= 0
- `minStockLevel`: Required, must be >= 0

### Stok Güncelle

```http
PUT /api/stocks/{id}
Content-Type: application/json

{
  "quantity": 150,
  "minStockLevel": 15,
  "reservedQuantity": 5
}
```

### Stoğa Ekle

```http
PUT /api/stocks/{id}/add?quantity=50
```

### Stoktan Çıkar

```http
PUT /api/stocks/{id}/remove?quantity=25
```

### Stok Rezerve Et

```http
PUT /api/stocks/{id}/reserve?quantity=10
```

### Rezervasyonu İptal Et

```http
PUT /api/stocks/{id}/release?quantity=5
```

### Stok Kaydı Sil

```http
DELETE /api/stocks/{id}
```

---

## Error Handling

### Common HTTP Status Codes

- `200 OK`: Başarılı istek
- `201 Created`: Başarılı oluşturma
- `204 No Content`: Başarılı silme
- `400 Bad Request`: Geçersiz istek (validation error)
- `404 Not Found`: Kaynak bulunamadı
- `409 Conflict`: Çakışma (unique constraint violation)
- `500 Internal Server Error`: Sunucu hatası

### Error Response Examples

**Validation Error:**
```json
{
  "success": false,
  "error": "Validation failed",
  "details": {
    "name": "Ürün adı gereklidir",
    "sku": "SKU gereklidir"
  }
}
```

**Not Found Error:**
```json
{
  "success": false,
  "error": "Product not found with id: 999"
}
```

**Conflict Error:**
```json
{
  "success": false,
  "error": "Product with SKU 'BD-001' already exists"
}
```

---

## Rate Limiting

Şu anda rate limiting implementasyonu yoktur. Production ortamında eklenmelidir.

## CORS

API, Cross-Origin Resource Sharing (CORS) için yapılandırılmıştır:

- `Access-Control-Allow-Origin`: *
- `Access-Control-Allow-Methods`: GET, POST, PUT, DELETE, OPTIONS
- `Access-Control-Allow-Headers`: Content-Type, Authorization

## Pagination

Büyük veri setleri için pagination desteği henüz eklenmemiştir. Gerektiğinde eklenebilir.

## Filtering & Sorting

### Query Parameters

Çoğu list endpoint'i şu query parameter'ları destekler:

- `?page=0&size=20`: Pagination
- `?sort=name,asc`: Sorting
- `?name=filter`: Filtering by name

## Versioning

API versioning şu anda URL path ile yapılmamaktadır. Gelecekte `/api/v1/` formatına geçilebilir.

---

## Örnek Kullanım

### JavaScript (Axios) ile API Çağrısı

```javascript
import axios from 'axios';

// Tüm ürünleri listele
const getProducts = async () => {
  try {
    const response = await axios.get('/api/products');
    console.log(response.data);
  } catch (error) {
    console.error('Error:', error.response?.data);
  }
};

// Yeni ürün oluştur
const createProduct = async (productData) => {
  try {
    const response = await axios.post('/api/products', productData);
    console.log('Created:', response.data);
  } catch (error) {
    console.error('Error:', error.response?.data);
  }
};

// Ürün güncelle
const updateProduct = async (id, productData) => {
  try {
    const response = await axios.put(`/api/products/${id}`, productData);
    console.log('Updated:', response.data);
  } catch (error) {
    console.error('Error:', error.response?.data);
  }
};
```

### cURL ile API Test

```bash
# Tüm kategorileri listele
curl -X GET http://localhost:8080/api/categories

# Yeni kategori oluştur
curl -X POST http://localhost:8080/api/categories \
  -H "Content-Type: application/json" \
  -d '{"name": "Yeni Kategori", "description": "Açıklama"}'

# Ürün ara
curl -X GET "http://localhost:8080/api/products/search?name=buzdolabı"
```

Bu dokümantasyon API'nin mevcut durumu için hazırlanmıştır. Yeni özellikler eklendikçe güncellenecektir.
