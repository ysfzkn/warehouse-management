# Warehouse Management System

Modern, mobil uyumlu bir depo yönetim sistemi. Beyaz eşya satan şirketler için özel olarak tasarlanmış bu sistem, depolarınızdaki ürünleri kategorisel ve sayısal olarak yönetmenizi, stok durumunu görüntüleyip güncellemenizi sağlar.

![Java](https://img.shields.io/badge/Java-17-orange)
![Spring Boot](https://img.shields.io/badge/Spring%20Boot-3.1.5-brightgreen)
![React](https://img.shields.io/badge/React-18.2.0-blue)
![License](https://img.shields.io/badge/License-MIT-yellow)

## 🌟 Özellikler

- **Multi-Warehouse Support**: Birden fazla depo yönetimi
- **Product Management**: Ürün kategorileme ve detaylı ürün bilgileri
- **Stock Tracking**: Gerçek zamanlı stok takibi ve uyarılar
- **Category Management**: Esnek kategori sistemi
- **Mobile Responsive**: Mobil cihazlarda mükemmel deneyim
- **Modern UI**: Bootstrap ile şık ve kullanıcı dostu arayüz
- **RESTful API**: Standart API endpoints
- **Docker Ready**: Containerized deployment
- **Real-time Dashboard**: Kapsamlı istatistik ve raporlar

## 📋 Gereksinimler

- **Docker & Docker Compose** (Önerilen)
- **Java 17+** (Eğer Docker kullanmıyorsanız)
- **Node.js 18+** (Eğer Docker kullanmıyorsanız)
- **Git**

## 🚀 Hızlı Başlangıç

### Docker ile (Önerilen)

1. **Repository'yi klonlayın:**
   ```bash
   git clone <repository-url>
   cd warehouse-management
   ```

2. **Deploy script'ini çalıştırın:**
   ```bash
   ./deploy.sh
   ```

3. **Sistemi kullanın:**
   - **Frontend**: http://localhost
   - **Backend API**: http://localhost/api
   - **H2 Console**: http://localhost:8080/h2-console

### Manuel Kurulum

1. **Backend'i başlatın:**
   ```bash
   # Maven dependencies'i indirin
   mvn clean install

   # Uygulamayı çalıştırın
   mvn spring-boot:run
   ```

2. **Frontend'i başlatın:**
   ```bash
   cd frontend
   npm install
   npm start
   ```

## 📊 Sistem Mimarisi

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   React Frontend │◄──►│  Spring Boot    │◄──►│   H2 Database   │
│                 │    │   Backend API   │    │  (In-Memory)    │
│ - Responsive UI │    │                 │    │                 │
│ - Modern Design │    │ - REST API      │    │ - JPA Entities  │
│ - Real-time     │    │ - Business      │    │ - Relationships │
│   Updates       │    │   Logic         │    │                 │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

## 🏗️ Veritabanı Şeması

### Categories (Kategoriler)
- `id`: Primary Key
- `name`: Kategori adı
- `description`: Açıklama
- `created_at`: Oluşturma tarihi
- `updated_at`: Güncelleme tarihi

### Warehouses (Depolar)
- `id`: Primary Key
- `name`: Depo adı
- `location`: Konum
- `phone`: Telefon
- `manager`: Yönetici
- `capacity_sqm`: Kapasite (m²)
- `is_active`: Aktif durumu

### Products (Ürünler)
- `id`: Primary Key
- `name`: Ürün adı
- `description`: Açıklama
- `sku`: Stok kodu
- `price`: Fiyat
- `weight`: Ağırlık
- `dimensions`: Boyutlar
- `category_id`: Kategori referansı
- `is_active`: Aktif durumu

### Stocks (Stoklar)
- `id`: Primary Key
- `product_id`: Ürün referansı
- `warehouse_id`: Depo referansı
- `quantity`: Miktar
- `min_stock_level`: Minimum stok seviyesi
- `reserved_quantity`: Rezerve miktar
- `last_updated`: Son güncelleme

## 🔌 API Endpoints

### Categories
- `GET /api/categories` - Tüm kategorileri listele
- `GET /api/categories/{id}` - Kategori detayları
- `POST /api/categories` - Yeni kategori oluştur
- `PUT /api/categories/{id}` - Kategori güncelle
- `DELETE /api/categories/{id}` - Kategori sil

### Warehouses
- `GET /api/warehouses` - Tüm depoları listele
- `GET /api/warehouses/{id}` - Depo detayları
- `POST /api/warehouses` - Yeni depo oluştur
- `PUT /api/warehouses/{id}` - Depo güncelle
- `DELETE /api/warehouses/{id}` - Depo sil
- `PUT /api/warehouses/{id}/activate` - Depo aktifleştir
- `PUT /api/warehouses/{id}/deactivate` - Depo pasifleştir

### Products
- `GET /api/products` - Tüm ürünleri listele
- `GET /api/products/{id}` - Ürün detayları
- `GET /api/products/sku/{sku}` - SKU ile ürün ara
- `POST /api/products` - Yeni ürün oluştur
- `PUT /api/products/{id}` - Ürün güncelle
- `DELETE /api/products/{id}` - Ürün sil

### Stocks
- `GET /api/stocks` - Tüm stokları listele
- `GET /api/stocks/{id}` - Stok detayları
- `GET /api/stocks/product/{productId}` - Ürüne göre stoklar
- `GET /api/stocks/warehouse/{warehouseId}` - Depoya göre stoklar
- `POST /api/stocks` - Yeni stok kaydı
- `PUT /api/stocks/{id}` - Stok güncelle
- `PUT /api/stocks/{id}/add` - Stok ekle
- `PUT /api/stocks/{id}/remove` - Stok çıkar

## 🎨 Kullanıcı Arayüzü

### Dashboard
- Genel istatistikler
- Düşük stok uyarıları
- Grafik ve chart'lar
- Hızlı erişim butonları

### Depo Yönetimi
- Depo listesi ve detayları
- Depo bazında stok görüntüleme
- Depo aktivasyonu/pasifleştirme

### Ürün Yönetimi
- Ürün listesi ve arama
- Kategori bazlı filtreleme
- Ürün ekleme/düzenleme

### Kategori Yönetimi
- Kategori hiyerarşisi
- Ürün sayıları
- Kategori bazlı raporlar

### Stok Yönetimi
- Gerçek zamanlı stok takibi
- Düşük stok uyarıları
- Stok hareketleri

## 🔧 Konfigürasyon

### Environment Variables (Backend)
```properties
# Server Configuration
server.port=8080

# Database Configuration
spring.datasource.url=jdbc:h2:mem:warehouse_db
spring.datasource.username=sa
spring.datasource.password=password

# H2 Console (Development)
spring.h2.console.enabled=true
```

### Docker Environment
```yaml
# docker-compose.yml
backend:
  environment:
    - SPRING_PROFILES_ACTIVE=docker
```

## 🐳 Docker Kullanımı

### Geliştirme Ortamı
```bash
# Tüm servisleri başlat
docker-compose up -d

# Logları görüntüle
docker-compose logs -f backend
docker-compose logs -f frontend

# Servisleri durdur
docker-compose down
```

### Production Deployment
```bash
# Production build
docker-compose -f docker-compose.prod.yml up -d

# SSL sertifikası ile
# nginx/prod.conf dosyasını düzenleyin
```

## 🚀 Production Deployment

### VPS/Dedicated Server
1. Repository'yi sunucuya klonlayın
2. SSL sertifikası alın (Let's Encrypt önerilir)
3. `nginx/prod.conf` dosyasını güncelleyin
4. `./deploy.sh production` komutunu çalıştırın

### Cloud Platforms
- **AWS**: ECS Fargate + RDS
- **Google Cloud**: Cloud Run + Cloud SQL
- **Azure**: Container Instances + Database
- **DigitalOcean**: App Platform

## 📱 Mobil Uyumluluk

- Responsive Bootstrap tasarımı
- Touch-friendly arayüz
- Progressive Web App (PWA) desteği
- Mobile-first yaklaşım

## 🔒 Güvenlik

- CORS konfigürasyonu
- Input validation
- SQL injection koruması (JPA)
- XSS koruması
- Security headers

## 📊 Performans

- Lazy loading
- Caching strategies
- Database indexing
- Optimized queries
- CDN desteği

## 🧪 Test

### Backend Tests
```bash
mvn test
```

### Frontend Tests
```bash
cd frontend
npm test
```

## 📝 Loglama

- Structured logging (Spring Boot)
- Request/Response logging
- Error tracking
- Performance monitoring

## 🔄 Backup & Recovery

### Database Backup (H2)
```bash
# H2 console üzerinden CSV export
http://localhost:8080/h2-console
```

### Docker Volumes
```bash
# Volume backup
docker run --rm -v warehouse_postgres_data:/data -v $(pwd):/backup alpine tar czf /backup/postgres_backup.tar.gz -C /data .
```

## 🤝 Katkıda Bulunma

1. Fork yapın
2. Feature branch oluşturun (`git checkout -b feature/amazing-feature`)
3. Commit yapın (`git commit -m 'Add amazing feature'`)
4. Push yapın (`git push origin feature/amazing-feature`)
5. Pull Request açın

## 📄 Lisans

Bu proje MIT lisansı altında lisanslanmıştır. Detaylar için [LICENSE](LICENSE) dosyasına bakın.

## 🆘 Destek

Herhangi bir sorun yaşarsanız:

1. [Issues](https://github.com/your-repo/issues) sayfasını kontrol edin
2. Yeni issue açın
3. Email ile iletişime geçin

## 👥 Geliştiriciler

- **Backend**: Spring Boot, Java 17, REST API
- **Frontend**: React 18, Bootstrap 5, Chart.js
- **Database**: H2 (Development), PostgreSQL (Production)
- **DevOps**: Docker, Docker Compose, Nginx

## 🗺️ Roadmap

- [ ] Multi-language support (TR/EN)
- [ ] Advanced reporting
- [ ] Barcode/QR code integration
- [ ] Mobile app (React Native)
- [ ] Real-time notifications
- [ ] Advanced analytics
- [ ] Multi-tenant support
- [ ] API rate limiting

---

⭐ Eğer bu projeyi beğendiyseniz, star vermeyi unutmayın!
