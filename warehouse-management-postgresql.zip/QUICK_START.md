# 🚀 Quick Start Guide

This guide provides step-by-step instructions to quickly get the Warehouse Management System up and running.

## 📋 Prerequisites

- **Docker & Docker Compose** (Recommended)
- **Git** (To clone the repository)

## 🛠️ Step 1: Prepare the Repository

```bash
# Clone the repository
git clone <repository-url>
cd warehouse-management

# Check file permissions
chmod +x deploy.sh
```

## 🚀 Step 2: Start the System

### Automatic Deployment (Recommended)

```bash
# Start the entire system with one command
./deploy.sh
```

This command:
- ✅ Builds Docker images
- ✅ Starts backend and frontend services
- ✅ Prepares the database
- ✅ Performs health checks
- ✅ Shows you access information

### Manual Installation (Alternative)

If you don't want to use Docker:

**Backend:**
```bash
# Install required dependencies
mvn clean install

# Start the application
mvn spring-boot:run
```

**Frontend:**
```bash
cd frontend
npm install
npm start
```

## 🌐 Step 3: Access the System

Once deployment is successful, you can access these URLs:

| Service | URL | Description |
|---------|-----|-------------|
| **Frontend** | http://localhost | Main application interface |
| **Backend API** | http://localhost/api | REST API endpoints |
| **H2 Console** | http://localhost:8080/h2-console | Database console |

## 🔑 Step 4: First Login

### Database Options

**Option 1: H2 (Development - Default):**
- **Console**: http://localhost:8080/h2-console
- **JDBC URL**: `jdbc:h2:mem:warehouse_db`
- **Username**: `sa`
- **Password**: `password`

**Option 2: PostgreSQL (Production):**
- **Host**: localhost
- **Port**: 5432
- **Database**: warehouse_db
- **Username**: warehouse_user
- **Password**: warehouse_pass

### First Use

1. **Open** http://localhost in your browser
2. **View** general statistics on the Dashboard page
3. **Create** your first category in the Categories section
4. **Add** products in the Products section
5. **Define** warehouses in the Warehouses section
6. **Create** stock records in the Stock section

## 📱 Mobile Usage

The system is mobile-friendly:
- 📱 Open browser on your phone
- 🌐 Go to http://localhost
- 📱 Experience mobile interface with responsive design

## 🛑 Stopping the System

```bash
# Stop all services
docker-compose down

# Or just with the deployment script
./deploy.sh # (stops existing containers)
```

## 🔍 Troubleshooting

### Common Issues

**Port Conflict:**
```bash
# If port 8080 is in use
docker-compose down
# Change the port or close the other application
```

**Build Error:**
```bash
# Clean cache and rebuild
docker-compose build --no-cache
```

**API Connection Error:**
- Make sure backend service is running
- Check logs with `docker-compose logs backend`

### Viewing Logs

```bash
# View all service logs
docker-compose logs

# Only backend logs
docker-compose logs backend

# Only frontend logs
docker-compose logs frontend

# Real-time log tracking
docker-compose logs -f
```

## 🎯 Example Usage Scenarios

### Scenario 1: Adding a New Product

1. **Categories** → **New Category** → Create "White Goods"
2. **Products** → **New Product** → Add Samsung Refrigerator
3. **Warehouses** → **New Warehouse** → Create Main Warehouse
4. **Stock** → **New Stock Record** → Set up product-warehouse-stock relationship

### Scenario 2: Stock Tracking

1. **Dashboard** → View general statistics
2. **Stock** → Check low stock alerts
3. **Stock Adjustment** to update quantities

### Scenario 3: Reporting

1. **Dashboard** → Analyze overall status from charts
2. **Warehouses** → View stocks by warehouse
3. **Products** → Filter products by category

## 📊 Sample Data

The system uses H2 in-memory database so it starts clean each time. Sample data for testing:

```sql
-- Sample category
INSERT INTO categories (name, description) VALUES ('White Goods', 'Refrigerator, washing machine, etc.');

-- Sample warehouse
INSERT INTO warehouses (name, location, manager) VALUES ('Main Warehouse', 'Istanbul', 'Ahmet Yılmaz');

-- Sample product
INSERT INTO products (name, sku, price, category_id) VALUES ('Samsung Refrigerator', 'REF-001', 15000.00, 1);
```

## 🔧 Advanced Configuration

### Environment Variables

Edit environment variables in `docker-compose.yml`:

```yaml
environment:
  - SPRING_PROFILES_ACTIVE=production
  - LOG_LEVEL=DEBUG
```

### Custom Port

```bash
# Use different port
FRONTEND_PORT=3000 BACKEND_PORT=8081 docker-compose up
```

## 🚀 Production Deployment

### VPS/Dedicated Server

1. **Get SSL certificate** (Let's Encrypt recommended)
2. **Set up your domain**
3. **Edit** nginx/prod.conf file
4. **Run deploy script:**

```bash
# In production environment
ENV=production ./deploy.sh
```

## ☁️ Cloud Database Setup (Free Options)

### Option 1: Supabase (Recommended for Beginners)

**Free Tier:** 500MB database + 2GB bandwidth

1. **Create Account:**
   - Go to [supabase.com](https://supabase.com)
   - Sign up for free account

2. **Create Project:**
   - Click "New Project"
   - Choose your organization
   - Enter project name: "warehouse-management"
   - Set password (remember this!)
   - Choose region (closest to your users)

3. **Get Connection Details:**
   - Go to Settings → Database
   - Copy the connection string

4. **Update Configuration:**
   ```properties
   # In application-postgres.properties
   spring.datasource.url=jdbc:postgresql://[YOUR-DB-HOST]:5432/postgres
   spring.datasource.username=postgres
   spring.datasource.password=[YOUR-PASSWORD]
   ```

5. **Deploy:**
   ```bash
   # Update environment variables in docker-compose.yml
   docker-compose up -d
   ```

### Option 2: Neon (PostgreSQL)

**Free Tier:** 512MB storage

1. **Create Account:**
   - Go to [neon.tech](https://neon.tech)
   - Sign up for free account

2. **Create Database:**
   - Click "Create a project"
   - Choose free tier
   - Copy connection string

3. **Configure Application:**
   ```yaml
   # docker-compose.yml
   backend:
     environment:
       - SPRING_DATASOURCE_URL=jdbc:postgresql://[NEON-HOST]:5432/neondb
       - SPRING_DATASOURCE_USERNAME=[NEON-USER]
       - SPRING_DATASOURCE_PASSWORD=[NEON-PASSWORD]
   ```

### Cloud vs Local Comparison

| Feature | Local PostgreSQL | Cloud Database |
|---------|------------------|----------------|
| **Setup Time** | 30 minutes | 5 minutes |
| **Maintenance** | You handle updates/backups | Automatic |
| **Cost** | Free (your hardware) | Free tier available |
| **Backup** | Manual configuration | Automatic daily backups |
| **Scaling** | Limited to your server | Auto-scaling possible |
| **Security** | You configure | Enterprise-grade security |

**For Your White Goods Business:**
- **Start with**: Supabase (free, easy setup)
- **Scale up**: AWS RDS or Google Cloud SQL (when you need more power)
- **Backup**: Always enable automatic backups

## 📞 Support

If you encounter any issues:

1. **Check logs**: `docker-compose logs`
2. **View container status**: `docker-compose ps`
3. **Perform health check**: `curl http://localhost/health`
4. **Read documentation**: [README.md](README.md)
5. **Open an issue** or send email

## 🎉 Success!

You have successfully started the system! Now you can perform your warehouse management operations digitally.

**First Steps:**
- 🔍 Explore the Dashboard
- 📦 Add your first product
- 🏪 Define your warehouses
- 📊 Review reports

Happy using! 🚀
